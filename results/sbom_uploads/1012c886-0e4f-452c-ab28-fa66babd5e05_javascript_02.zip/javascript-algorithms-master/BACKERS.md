# Project Backers

> You may support this project via ❤️️ [GitHub](https://github.com/sponsors/trekhleb) or ❤️️ [Patreon](https://www.patreon.com/trekhleb).

## `O(2ⁿ)` Backers

`null`

## `O(n²)` Backers

`null`

## `O(n×log(n))` Backers

`null`

<!--
<table>
  <tr>
    <td align="center">
      <a href="[PROFILE_URL]">
        <img
          src="[PROFILE_IMG_SRC]"
          width="50"
          height="50"
        />
      </a>
      <br />
      <a href="[PROFILE_URL]">[PROFILE_NAME]</a>
    </td>
  </tr>
</table>
-->

<!--
<ul>
  <li>
    <a href="[PROFILE_URL]">
      <img
        src="[PROFILE_IMG_SRC]"
        width="30"
        height="30"
      /></a>
    &thinsp;
    <a href="[PROFILE_URL]">[PROFILE_NAME]</a>
  </li>
</ul>
-->
