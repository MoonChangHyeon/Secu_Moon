// CHECKSTYLE_OFF: RegexpHeader
/**
 * This package contains non-functional annotations which are
 * used to tag various elements and help users understanding
 * how those types should be used.
 *
 * @since 4.0.0
 */
@Experimental
package org.apache.maven.api.annotations;
